// // *   Created By:  Mohammad Shamsi    *|*    Email:  mshamsi502@gmail.com
// // *   Project Name:  mobile_jeanswest_app_android    *|*    App Name: Jeanswest
// // *   Created Date & Time:  2021-01-01  ,  10:00 AM
// // ****************************************************************************

// import 'package:jeanswest/src/models/coupon/coupon.dart';

// Coupon firstCoupon = new Coupon(
//   title: 'بن هدیه کلکسیون پاییزه 2020',
//   conditions: [
//     'قابل استفاده برای خرید های بیش از 200000 تومان',
//     'قابل استفاده برای خرید حضوری از فروشگاه های جین وست',
//   ],
//   price: '100000',
//   startDay: '12',
//   startMonth: '07',
//   startYear: '99',
//   endDay: '30',
//   endMonth: '07',
//   endYear: '99',
// );
// Coupon secondCoupon = new Coupon(
//   title: 'بن هدیه خرید کفش',
//   conditions: [
//     'قابل استفاده برای خرید های بیش از 500000 تومان',
//     'قابل استفاده برای خرید از دسته بندی کفش',
//     'قابل استفاده برای خرید حضوری از فروشگاه های جین وست',
//   ],
//   price: '250000',
//   startDay: '12',
//   startMonth: '07',
//   startYear: '99',
//   endDay: '30',
//   endMonth: '07',
//   endYear: '99',
// );
// Coupon thirdCoupon = new Coupon(
//   title: 'بن هدیه برای خرید های بالای 3000000 تومان',
//   conditions: [
//     'قابل استفاده برای خرید های بیش از 3000000 تومان',
//     'قابل استفاده برای خرید هدیه (از دسته بندی زنانه و بچگانه) ',
//     'قابل استفاده در خرید از فروشگاه های جین وست و فروشگاه ایترنتی بانی مد',
//     'قابل استفاده در سبد کالایی که دارای حداقل یک کالا با برند جین وست باشد',
//   ],
//   price: '1000000',
//   startDay: '01',
//   startMonth: '09',
//   startYear: '99',
//   endDay: '29',
//   endMonth: '12',
//   endYear: '99',
// );
// Coupon fourthCoupon = new Coupon(
//   title: 'بن هدیه کلکسیون پاییزه 2020',
//   conditions: [
//     'قابل استفاده برای خرید های بیش از 200000 تومان',
//     'قابل استفاده برای خرید حضوری از فروشگاه های جین وست',
//   ],
//   price: '100000',
//   startDay: '12',
//   startMonth: '07',
//   startYear: '99',
//   endDay: '30',
//   endMonth: '07',
//   endYear: '99',
// );

// List<Coupon> myCoupons = [
//   firstCoupon,
//   secondCoupon,
//   thirdCoupon,
//   fourthCoupon,
// ];
// //
