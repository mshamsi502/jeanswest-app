// // *   Created By:  Mohammad Shamsi    *|*    Email:  mshamsi502@gmail.com
// // *   Project Name:  mobile_jeanswest_app_android    *|*    App Name: Jeanswest
// // *   Created Date & Time:  2021-01-01  ,  10:00 AM
// // ****************************************************************************

// String firstDepartment = 'پشتیبان خرید';
// String secondDepartment = 'پشتیبان باشگاه مشتریان';
// String otherDepartment = 'دیگر';
// List<String> departments = [
//   firstDepartment,
//   secondDepartment,
//   otherDepartment,
// ];
