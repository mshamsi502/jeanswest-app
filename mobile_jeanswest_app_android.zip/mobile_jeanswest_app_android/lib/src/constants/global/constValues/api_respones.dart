import 'package:flutter/material.dart';
import 'package:jeanswest/src/constants/global/constValues/colors.dart';

// ! 20? Range
const Map<String, dynamic> sc200 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc201 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc202 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc203 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc204 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc205 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc206 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc207 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc208 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
//
// ! 22? Range
Map<String, dynamic> sc226 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
//
// ! 30? Range
Map<String, dynamic> sc300 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc301 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc302 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc303 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc304 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc305 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc306 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc307 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
Map<String, dynamic> sc308 = {
  "statusCode": 200,
  "engMessage": "OK",
  "perMessage": "موفقیت آمیز",
  "textColor": GREEN_TEXT_COLOR,
};
//
// ! 40? Range
Map<String, dynamic> sc400 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc401 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc402 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc403 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc404 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc405 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc406 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc407 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc408 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc409 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
//
// ! 40? Range
Map<String, dynamic> sc410 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc411 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc412 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc413 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc414 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc415 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc416 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc417 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
Map<String, dynamic> sc418 = {
  "statusCode": 404,
  "engMessage": "Not Found!",
  "perMessage": "پیدا نشد!",
  "textColor": Colors.black,
};
//
// !
Map<String, dynamic> sc429 = {
  "statusCode": 429,
  "engMessage": "Too Many Attempts",
  "perMessage": "چند دقیقه بعد مجددا تلاش فرمایید",
  "textColor": RED_ERROR_COLOR,
};

//
Map<int, Map<String, dynamic>> statusCodes = {
  200: sc200,
  201: sc201,
  202: sc202,
  203: sc203,
  204: sc204,
  205: sc205,
  206: sc206,
  207: sc207,
  208: sc208,
  //!
  226: sc226,
  //!
  300: sc300,
  301: sc301,
  302: sc302,
  303: sc303,
  304: sc304,
  305: sc305,
  306: sc306,
  307: sc307,
  308: sc308,
  //!
  400: sc400,
  401: sc401,
  402: sc402,
  403: sc403,
  404: sc404,
  405: sc405,
  406: sc406,
  407: sc407,
  408: sc408,
  409: sc409,
  //!
  410: sc410,
  411: sc411,
  412: sc412,
  413: sc413,
  414: sc414,
  415: sc415,
  416: sc416,
  417: sc417,
  418: sc418,
  //!
  429: sc429,
};
