// *   Created By:  Mohammad Shamsi    *|*    Email:  mshamsi502@gmail.com
// *   Project Name:  mobile_jeanswest_app_android    *|*    App Name: Jeanswest
// *   Created Date & Time:  2021-01-01  ,  10:00 AM
// ****************************************************************************
//
const bool MANUAL_TOKEN_IS_ENABLE = false;
// const bool MANUAL_TOKEN_IS_ENABLE = true;
const String MANUAL_TOKEN =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzZWNyZXQiOiI4YjQzNzhlMS1hNjI2LTQwZWYtYWE0Yy05YWE3MmEyOGUyZmEiLCJpYXQiOjE2MjIzNTEyMTMsImV4cCI6MTY1Mzg4NzIxM30.VXhGD7JbIWiiraiN_J5mYOIadcm_VtiKq-19ftC3FDg';

//
// const bool MOCK_IS_ENABLE = false;
const bool MOCK_IS_ENABLE = true;
//
const bool HARDCORE_DATA_IS_ENABLE = false;
// const bool HARDCORE_DATA_IS_ENABLE = true;
int tryToGetAllUserInfo = 4;
bool showCompeletProfileMessage = false;
