
import 'package:jeanswest/src/models/api_response/globalRes/contactUs/contact-us-data.dart';

ContactUsData contactUsInfo = ContactUsData(
  email: '',
  phone: '',
  fax: '',
);

// ! temp hardcore data
ContactUsData contactUsTempInfo = ContactUsData(
  email: 'info@Jeanswest.com',
  phone: '02191070544',
  fax: '1475614566',
);
