import 'package:jeanswest/src/models/api_response/globalRes/faq/faq-data.dart';

List<FAQData> inviteFriendsFAQ = [FAQData(question: "", answer: "")];
