import 'package:jeanswest/src/models/profile/user/user-invite-info.dart';

UserInviteInfo userInvite = new UserInviteInfo(
  someOfInvited: 0,
  someOfInstallFromInvited: 0,
  someOfShoppingFromInvited: 0,
  receivedGift: 0,
);
