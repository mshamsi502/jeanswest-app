import 'package:jeanswest/src/models/profile/user/user-payment-info.dart';

UserPaymentInfo userPayment = UserPaymentInfo(
  tblPosCustomersID: "",
  payRial: 0,
  cusType: "",
  cTypeName: "",
  priceLevel: 0,
  priceLevelTo: 0,
);
