
import 'package:jeanswest/src/models/api_response/userRes/userPayment/user-payment-info-data.dart';

UserPaymentInfoData userPayment = new UserPaymentInfoData(
  moneyBuying: 0,
);
