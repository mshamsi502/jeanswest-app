import 'package:jeanswest/src/models/profile/message/single-message.dart';

List<SingleMessage> userMessages = [
  SingleMessage(
    code: 0,
    engTitle: "",
    perTitle: "",
    engSender: "",
    perSender: "",
    pictureAssets: "",
    text: "",
    description: [""],
    price: 0,
    minShopping: 0,
    engCategory: [""],
    perCategory: [""],
    startDate: "",
    endDate: "",
    sendDate: "",
  ),
];
