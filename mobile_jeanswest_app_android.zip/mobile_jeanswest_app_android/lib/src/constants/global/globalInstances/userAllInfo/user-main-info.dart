import 'package:jeanswest/src/models/profile/user/user-main-info.dart';

UserMainInfo user = new UserMainInfo(
  code: "",
  firstName: 'کاربر',
  lastName: 'جدید',
  email: 'your_email@gmail.com',
  phoneNumber: '+989121234567',
  gender: 1,
  dayOfBirthGeo: '24',
  monthOfBirthGeo: '07',
  yearOfBirthGeo: '1375',
);
