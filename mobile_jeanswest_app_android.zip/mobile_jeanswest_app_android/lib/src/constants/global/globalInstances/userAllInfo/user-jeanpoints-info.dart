import 'package:jeanswest/src/models/coupon/coupon.dart';

List<Coupon> userJeanpointBons = [
  Coupon(
    code: 0,
    engName: '',
    perName: '',
    description: ['', ''],
    price: 0,
    minShopping: 0,
    startDate: '',
    endDate: '',
    //
    yearOfStartDate: '',
    monthOfStartDate: '',
    dayOfStartDate: '',
    yearOfEndDate: '',
    monthOfEndDate: '',
    dayOfEndDate: '',
  ),
];
