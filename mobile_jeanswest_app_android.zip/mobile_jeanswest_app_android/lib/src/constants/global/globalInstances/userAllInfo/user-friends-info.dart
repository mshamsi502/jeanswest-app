// import 'package:jeanswest/src/models/profile/user/user-friends-info.dart';

// UserFriendsInfo userFriends = new UserFriendsInfo(friends: []);
