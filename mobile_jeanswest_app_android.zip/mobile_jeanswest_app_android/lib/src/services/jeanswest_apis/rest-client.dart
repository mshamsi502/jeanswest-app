import 'package:dio/dio.dart';

class RestClient {
  RestClient(Dio dio, {String baseUrl});
}
