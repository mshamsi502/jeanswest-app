// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'card-about-us.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CardAboutUsData _$CardAboutUsDataFromJson(Map<String, dynamic> json) {
  return CardAboutUsData(
    text: json['text'] as String,
    picture: json['picture'] as String,
  );
}

Map<String, dynamic> _$CardAboutUsDataToJson(CardAboutUsData instance) =>
    <String, dynamic>{
      'text': instance.text,
      'picture': instance.picture,
    };
