// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'banimode-features-product-res.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BanimodeFeaturesProductRes _$BanimodeFeaturesProductResFromJson(
    Map<String, dynamic> json) {
  return BanimodeFeaturesProductRes(
    title: json['title'] as String,
    value: json['value'] as String,
  );
}

Map<String, dynamic> _$BanimodeFeaturesProductResToJson(
        BanimodeFeaturesProductRes instance) =>
    <String, dynamic>{
      'title': instance.title,
      'value': instance.value,
    };
