// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'get-token-res.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GetTokenRes _$GetTokenResFromJson(Map<String, dynamic> json) {
  return GetTokenRes(
    accessToken: json['accessToken'] as String,
  );
}

Map<String, dynamic> _$GetTokenResToJson(GetTokenRes instance) =>
    <String, dynamic>{
      'accessToken': instance.accessToken,
    };
