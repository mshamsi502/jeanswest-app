// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user-tbl-pos-cust-data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserTblPosCustData _$UserTblPosCustDataFromJson(Map<String, dynamic> json) {
  return UserTblPosCustData(
    tblPosCustomersID: json['tblPosCustomers_ID'] as String,
  );
}

Map<String, dynamic> _$UserTblPosCustDataToJson(UserTblPosCustData instance) =>
    <String, dynamic>{
      'tblPosCustomers_ID': instance.tblPosCustomersID,
    };
