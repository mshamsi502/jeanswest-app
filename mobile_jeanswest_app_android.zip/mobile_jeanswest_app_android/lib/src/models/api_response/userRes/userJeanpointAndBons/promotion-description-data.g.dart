// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'promotion-description-data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PromotionDescriptionData _$PromotionDescriptionDataFromJson(
    Map<String, dynamic> json) {
  return PromotionDescriptionData(
    context: json['context'] as String,
    message: json['message'] as String,
  );
}

Map<String, dynamic> _$PromotionDescriptionDataToJson(
        PromotionDescriptionData instance) =>
    <String, dynamic>{
      'context': instance.context,
      'message': instance.message,
    };
