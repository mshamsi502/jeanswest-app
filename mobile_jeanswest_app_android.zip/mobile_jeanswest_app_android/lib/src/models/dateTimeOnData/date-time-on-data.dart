// *   Created By:  Mohammad Shamsi    *|*    Email:  mshamsi502@gmail.com
// *   Project Name:  mobile_jeanswest_app_android    *|*    App Name: Jeanswest
// *   Created Date & Time:  2021-01-01  ,  10:00 AM
// ****************************************************************************

// ignore: must_be_immutable

class DateTimeOnData {
  final String createdAt;
  final String updatedAt;
  final String deletedAt;

  DateTimeOnData({
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
  });
}
