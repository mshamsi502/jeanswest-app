// *   Created By:  Mohammad Shamsi    *|*    Email:  mshamsi502@gmail.com
// *   Project Name:  mobile_jeanswest_app_android    *|*    App Name: Jeanswest
// *   Created Date & Time:  2021-01-01  ,  10:00 AM
// ****************************************************************************

class UserInviteInfo {
  int receivedGift;
  int someOfInvited;
  int someOfInstallFromInvited;
  int someOfShoppingFromInvited;

  UserInviteInfo({
    this.receivedGift,
    this.someOfInvited,
    this.someOfInstallFromInvited,
    this.someOfShoppingFromInvited,
  });
}
