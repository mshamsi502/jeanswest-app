// *   Created By:  Mohammad Shamsi    *|*    Email:  mshamsi502@gmail.com
// *   Project Name:  mobile_jeanswest_app_android    *|*    App Name: Jeanswest
// *   Created Date & Time:  2021-01-01  ,  10:00 AM
// ****************************************************************************

class  ExactTimeOrder {
  final String yearOfDate;
  final String mouthOfDate;
  final String dayOfDate;
  final String hourOfDate;
  final String minuteOfDate;
  final String perExplain;

  ExactTimeOrder({
    this.yearOfDate,
    this.mouthOfDate,
    this.dayOfDate,
    this.hourOfDate,
    this.minuteOfDate,
    this.perExplain,
  });
}
